"""
Admin handlers
"""

from .admin_handlers import *
from .history_handlers import *