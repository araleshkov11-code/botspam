"""
Logging utilities for TgBlaster events
"""

from .logger import *